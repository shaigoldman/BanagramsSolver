# BanagramsSolver
Shai Goldman and Aaron Priven's parallel haskell project for PFP fall 22
